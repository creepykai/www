<?php
// $barcelona = ['Barcelona' => 0, 'Coruña' => 1188, 'Madrid' => 621, 'Sevilla' => 1046];
// $corunia = ['Barcelona' => 1188, 'Coruña' => 0, 'Madrid' => 609, 'Sevilla' => 947];
// $madrid = ['Barcelona' => 621, 'Coruña' => 609, 'Madrid' => 0, 'Sevilla' => 538];
// $sevilla = ['Barcelona' => 1046, 'Coruña' => 947, 'Madrid' => 538, 'Sevilla' => 0];

// $distancias = [
//     'Barcelona' => $barcelona,
//     'Coruña' => $corunia,
//     'Madrid' => $madrid,
//     'Sevilla' => $sevilla
// ];
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8" />
        <title>Actividad 3.11</title>
    </head>
    <body>
        <?php
        if (!isset($_POST['']))  //TODO
        ?>
    </body>
</html>
