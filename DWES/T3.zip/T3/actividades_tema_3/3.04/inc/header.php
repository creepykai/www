<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8" />
        <title>Actividad 3.4</title>
    </head>
    <body>
        <h1>Hola</h1>