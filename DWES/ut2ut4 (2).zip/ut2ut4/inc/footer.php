</main> 

    <footer class="bg-dark text-white text-center p-3 fixed-bottom">
        <p class="mb-0">&copy; 2025 - DWES - Irene Diges</p>
    </footer>

</body>
</html>