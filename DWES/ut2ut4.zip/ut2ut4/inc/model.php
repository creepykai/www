<?php
define('FILE_JUGADORES', __DIR__ . '/../jugadores.csv');
define('FILE_PREGUNTAS', __DIR__ . '/../preguntas.txt');
define('FILE_PAISES',    __DIR__ . '/../paises.txt');
define('FILE_PARTIDAS',  __DIR__ . '/../partidas.csv');

function leerJugadores() : array {
    $jugadores = [];
    
    if (file_exists(FILE_JUGADORES)) {
        $lineas = file(FILE_JUGADORES, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lineas !== false) {
            foreach ($lineas as $linea) {
                $datos = explode(';', $linea);
                if (count($datos) >= 7) {
                    $datos[7] = 0;
                    $jugadores[] = $datos;
                }
            }
        }
    }

    if (file_exists(FILE_PARTIDAS)) {
        $lineasPartidas = file(FILE_PARTIDAS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lineasPartidas !== false) {
            foreach ($lineasPartidas as $lp) {
                $partida = explode(';', $lp); 
                if (count($partida) >= 3) {
                    $usuarioPartida = $partida[1];
                    $puntosPartida = (int)$partida[2];

                    foreach ($jugadores as &$j) {
                        if ($j[0] == $usuarioPartida) {
                            if ($puntosPartida > $j[7]) {
                                $j[7] = $puntosPartida;
                            }
                        }
                    }
                }
            }
        }
    }
    return $jugadores;
}

function leerPaises() : array {
    if (!file_exists(FILE_PAISES)) return [];
    
    $contenido = file(FILE_PAISES, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    return $contenido === false ? [] : $contenido;
}

function leerPreguntas() : array {
    $preguntas = [];
    if (file_exists(FILE_PREGUNTAS)) {
        $lineas = file(FILE_PREGUNTAS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lineas !== false) {
            foreach ($lineas as $linea) {
                $datos = explode(';', $linea);
                if (count($datos) >= 6) {
                    $preguntas[] = $datos;
                }
            }
        }
    }
    return $preguntas;
}

function leerPreguntaPorId(int $id) : ?array {
    $todas = leerPreguntas();
    return $todas[$id] ?? null;
}

function buscarJugadorPorUsuario(string $usuario) : ?array {
    $jugadores = leerJugadores();
    foreach ($jugadores as $jugador) {
        if ($jugador[0] === $usuario) {
            return $jugador;
        }
    }
    return null;
}

function guardarPregunta(array $datos, ?int $id = null) : bool {
    $todas = leerPreguntas();
    
    $nuevaLineaArray = [
        $datos['pregunta'],
        $datos['opcion1'],
        $datos['opcion2'],
        $datos['opcion3'],
        $datos['categoria'],
        $datos['correcta']
    ];
    
    if ($id !== null && isset($todas[$id])) {
        $todas[$id] = $nuevaLineaArray;
    } else {
        $todas[] = $nuevaLineaArray;
    }

    $contenido = "";
    foreach ($todas as $p) {
        $contenido .= implode(';', $p) . PHP_EOL;
    }
    
    return file_put_contents(FILE_PREGUNTAS, $contenido) !== false;
}

    function guardarJugador(array $datos, string $usuario) : bool {
    $jugadores = leerJugadores();
    $encontrado = false;
    
    $nuevoRegistro = [
        $datos['username'],
        $datos['password'],
        $datos['nombreCompleto'],
        $datos['pais'],
        $datos['telefono'],
        $datos['correo'],
        $datos['avatar']
    ];

    foreach ($jugadores as $key => $j) {
        if ($j[0] == $usuario) {
            $jugadores[$key] = $nuevoRegistro; 
            $encontrado = true;
            break;
        }
    }

    if (!$encontrado) {
        $jugadores[] = $nuevoRegistro;
    }

    $contenido = "";
    foreach ($jugadores as $j) {
        $camposGuardar = array_slice($j, 0, 7);
        $contenido .= implode(';', $camposGuardar) . PHP_EOL;
    }

    return file_put_contents(FILE_JUGADORES, $contenido) !== false;
}

function guardarPartida(string $usuario, int $puntos, int $totales, int $acertadas) : bool {
    $fecha = date('Y-m-d H:i:s');
    $linea = implode(';', [$fecha, $usuario, $puntos, $totales, $acertadas]) . PHP_EOL;
    return file_put_contents(FILE_PARTIDAS, $linea, FILE_APPEND) !== false;
}
?>